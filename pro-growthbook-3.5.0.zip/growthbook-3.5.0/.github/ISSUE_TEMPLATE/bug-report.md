---
name: 🐞 Bug Report
about: Create a report to help us improve
title: "[Bug] "
labels: bug
assignees: ""
---

### Summary

<!-- Please provide a summary of the bug -->

#### Expected Behavior

<!--- Tell us what should happen -->

#### Current Behavior

<!--- Tell us what happens instead of the expected behavior -->
