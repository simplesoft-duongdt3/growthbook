Plop templates are for code generation with Plop.js

## Usage

    yarn plop

Then choose a template you'd like to generate.
