"""Top-level package for GrowthBook Stats."""

__version__ = "0.8.0"
