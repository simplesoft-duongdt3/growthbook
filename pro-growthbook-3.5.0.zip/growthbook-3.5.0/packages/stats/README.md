# GrowthBook Stats

The stats engine for GrowthBook, the open source A/B testing platform.

## Installation

```
pip install gbstats
```

## Usage

```python
import gbstats
```
