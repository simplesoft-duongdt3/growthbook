export interface WatchInterface {
  userId: string;
  organization: string;
  experiments: string[];
  features: string[];
}
