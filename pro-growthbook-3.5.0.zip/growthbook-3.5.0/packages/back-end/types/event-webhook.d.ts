export {
  EventWebHookPayloadType,
  EventWebHookMethod,
  EventWebHookInterface,
} from "back-end/src/validators/event-webhook";
