export { CreateProps, UpdateProps } from "back-end/src/models/BaseModel";
