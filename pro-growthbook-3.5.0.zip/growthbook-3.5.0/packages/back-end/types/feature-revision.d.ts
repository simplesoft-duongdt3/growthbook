export {
  RevisionLog,
  FeatureRevisionInterface,
} from "back-end/src/validators/features";
