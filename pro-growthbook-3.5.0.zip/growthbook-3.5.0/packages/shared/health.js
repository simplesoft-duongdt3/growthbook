module.exports = require("./dist/health");
