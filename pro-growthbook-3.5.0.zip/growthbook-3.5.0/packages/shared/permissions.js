module.exports = require("./dist/permissions");
