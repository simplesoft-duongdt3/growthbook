module.exports = require("./dist/settings");
