module.exports = require("./dist/power");
