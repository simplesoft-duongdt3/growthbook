# Utils folder

This folder is meant to contain all utility files and functions.
